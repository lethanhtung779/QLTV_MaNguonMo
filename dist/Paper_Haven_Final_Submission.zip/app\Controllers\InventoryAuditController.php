<?php
declare(strict_types=1);

namespace Library\Controllers;

use Library\Repositories\ActivityRepository;
use Library\Repositories\BookRepository;
use Library\Repositories\CopyRepository;
use Library\Repositories\InventoryAuditRepository;
use Library\Services\BarcodeService;
use RuntimeException;
use Throwable;

final class InventoryAuditController extends Controller
{
    public function index(): void
    {
        require_permission('books.view');
        $repo = new InventoryAuditRepository($this->db);
        $audits = $repo->listAudits();

        $this->render('admin/inventory_audits', [
            'title' => 'Kiểm kê thư viện',
            'audits' => $audits,
        ], 'layouts/app');
    }

    public function create(): void
    {
        validate_csrf();
        $user = require_permission('books.create');

        $title = trim((string) ($_POST['title'] ?? ''));
        $scope = trim((string) ($_POST['scope'] ?? 'all'));
        $notes = trim((string) ($_POST['notes'] ?? ''));

        if ($title === '') {
            $this->fail('Vui lòng nhập tên đợt kiểm kê.', '/admin/inventory/audits');
        }

        try {
            $repo = new InventoryAuditRepository($this->db);
            $audit = $repo->createAudit($title, $scope, (int) $user['id'], $notes ?: null);

            (new ActivityRepository($this->db))->log(
                (int) $user['id'],
                'inventory_audit_created',
                'inventory_audit',
                (int) $audit['id'],
                'Tạo đợt kiểm kê: ' . $audit['audit_code'] . ' - ' . $title
            );

            $this->success('Đã tạo đợt kiểm kê mới thành công.', '/admin/inventory/audits/' . (int) $audit['id']);
        } catch (Throwable $e) {
            $this->fail('Lỗi tạo đợt kiểm kê: ' . $e->getMessage(), '/admin/inventory/audits');
        }
    }

    public function detail(int $id): void
    {
        require_permission('books.view');
        $repo = new InventoryAuditRepository($this->db);
        $audit = $repo->findAudit($id);
        if (!$audit) {
            http_response_code(404);
            $this->render('errors/404', ['title' => 'Không tìm thấy đợt kiểm kê'], 'layouts/app');
            return;
        }

        $items = $repo->auditItems($id);
        $missing = $repo->missingCopies($id);

        $this->render('admin/inventory_audit_detail', [
            'title' => 'Chi tiết kiểm kê: ' . $audit['audit_code'],
            'audit' => $audit,
            'items' => $items,
            'missing' => $missing,
        ], 'layouts/app');
    }

    public function scan(int $id): void
    {
        validate_csrf();
        $user = require_permission('books.update');

        $code = trim((string) ($_POST['code'] ?? ''));
        $condition = trim((string) ($_POST['condition'] ?? 'good'));
        $location = trim((string) ($_POST['location'] ?? ''));

        try {
            $repo = new InventoryAuditRepository($this->db);
            $result = $repo->scanCopy($id, $code, (int) $user['id'], $condition, $location ?: null);

            $msg = 'Đã ghi nhận quét bản sao: ' . $result['copy']['copy_code'] . ' (' . $result['copy']['book_title'] . ').';
            if (!empty($result['already_scanned'])) {
                $msg = 'Bản sao ' . $result['copy']['copy_code'] . ' đã được quét trước đó; hệ thống đã cập nhật tình trạng mới nhất.';
            }
            if (!$result['is_matched']) {
                $msg .= ' [LƯU Ý: Vị trí thực tế khác vị trí kệ hệ thống]';
            }
            if (($result['copy']['status'] ?? '') === 'on_loan') {
                $msg .= ' [CẢNH BÁO: Bản sao này hệ thống đang ghi nhận đang mượn]';
            }

            $this->success($msg, '/admin/inventory/audits/' . $id);
        } catch (Throwable $e) {
            $this->fail($e->getMessage(), '/admin/inventory/audits/' . $id);
        }
    }

    public function complete(int $id): void
    {
        validate_csrf();
        $user = require_permission('books.update');
        $notes = trim((string) ($_POST['notes'] ?? ''));

        try {
            $repo = new InventoryAuditRepository($this->db);
            $audit = $repo->completeAudit($id, (int) $user['id'], $notes ?: null);

            (new ActivityRepository($this->db))->log(
                (int) $user['id'],
                'inventory_audit_completed',
                'inventory_audit',
                $id,
                'Hoàn thành đợt kiểm kê: ' . $audit['audit_code']
            );

            $this->success('Đã hoàn tất và chốt biên bản kiểm kê thành công.', '/admin/inventory/audits/' . $id);
        } catch (Throwable $e) {
            $this->fail('Lỗi: ' . $e->getMessage(), '/admin/inventory/audits/' . $id);
        }
    }

    public function export(int $id): void
    {
        require_permission('books.view');
        $repo = new InventoryAuditRepository($this->db);
        $audit = $repo->findAudit($id);
        if (!$audit) {
            http_response_code(404);
            exit;
        }

        $items = $repo->auditItems($id);
        $missing = $repo->missingCopies($id);

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="kiem-ke-' . $audit['audit_code'] . '.csv"');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM for Excel
        fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

        fputcsv($out, ['BIÊN BẢN KIỂM KÊ THƯ VIỆN PAPER HAVEN']);
        fputcsv($out, ['Mã đợt:', $audit['audit_code'], 'Tiêu đề:', $audit['title']]);
        fputcsv($out, ['Trạng thái:', $audit['status'], 'Ngày bắt đầu:', $audit['started_at'], 'Người tạo:', $audit['starter_name']]);
        fputcsv($out, ['Tổng sách dự kiến:', $audit['total_expected'], 'Đã quét:', $audit['total_scanned'], 'Khớp vị trí:', $audit['total_matched'], 'Thiếu:', $audit['total_missing'], 'Lệch vị trí:', $audit['total_misplaced'], 'Hư hỏng:', $audit['total_damaged']]);
        fputcsv($out, []);

        fputcsv($out, ['--- DANH SÁCH BẢN SAO ĐÃ QUÉT ---']);
        fputcsv($out, ['Mã bản sao', 'Barcode', 'Tên sách', 'Vị trí kệ hệ thống', 'Vị trí quét', 'Tình trạng hệ thống', 'Tình trạng quét', 'Khớp vị trí', 'Thời gian quét', 'Người quét']);
        foreach ($items as $item) {
            fputcsv($out, [
                $item['copy_code'],
                $item['barcode'] ?? '',
                $item['book_title'],
                $item['expected_location'] ?? '',
                $item['scanned_location'] ?? '',
                $item['expected_condition'],
                $item['scanned_condition'],
                $item['is_matched'] ? 'ĐÚNG' : 'LỆCH VỊ TRÍ',
                $item['scanned_at'],
                $item['scanner_name']
            ]);
        }

        fputcsv($out, []);
        fputcsv($out, ['--- DANH SÁCH BẢN SAO THIẾU / CHƯA QUÉT ---']);
        fputcsv($out, ['Mã bản sao', 'Barcode', 'Tên sách', 'Vị trí dự kiến', 'Tình trạng', 'Trạng thái lưu hành']);
        foreach ($missing as $m) {
            fputcsv($out, [
                $m['copy_code'],
                $m['barcode'] ?? '',
                $m['book_title'],
                $m['shelf_location'] ?? '',
                $m['item_condition'],
                $m['status']
            ]);
        }

        fclose($out);
        exit;
    }

    public function barcode(string $code): void
    {
        header('Content-Type: image/svg+xml');
        echo (new BarcodeService())->renderBarcodeSvg($code);
        exit;
    }

    public function qr(string $code): void
    {
        header('Content-Type: image/svg+xml');
        echo (new BarcodeService())->renderQrSvg($code);
        exit;
    }

    public function printLabels(int $bookId): void
    {
        require_permission('books.view');
        $book = (new BookRepository($this->db))->find($bookId);
        if (!$book) {
            http_response_code(404);
            $this->render('errors/404', ['title' => 'Không tìm thấy sách'], 'layouts/app');
            return;
        }

        $copies = (new CopyRepository($this->db))->all($bookId);
        $this->render('admin/print_labels', [
            'title' => 'In tem mã sách: ' . $book['title'],
            'book' => $book,
            'copies' => $copies,
        ], 'layouts/app');
    }
}
