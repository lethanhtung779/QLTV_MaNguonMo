# BÁO CÁO ĐỐI SOÁT & TÍCH HỢP BÌA SÁCH THẬT (BOOK COVER MATCH REPORT)
## Dự án: Paper Haven — Hệ thống Quản lý Thư viện Trực tuyến
**Ngày thực hiện:** 18/10/2026  
**Nguồn dữ liệu đối soát:** Bộ ảnh `Paper_Haven_Bia_Sach_Doi_Soat.zip` (56 files gồm 54 ảnh gốc + 2 trang tài liệu HTML).  
**Quy tắc đối chiếu:** Tuyệt đối chính xác 100% theo Tên sách, Tác giả, Dịch giả, Nhà xuất bản và Ấn bản. Không gán sai lệch, không dùng bìa AI, không bịa đặt nguồn gốc.

---

## 1. TỔNG KẾT KẾT QUẢ ĐỐI SOÁT

| Chỉ tiêu | Số lượng | Tỷ lệ | Ghi chú |
|---|---|---|---|
| **Tổng số file đối soát trong ZIP** | **56** | 100% | 54 file ảnh (JPEG, PNG, WebP) + 2 file HTML NXB/Tiki |
| **Bìa khớp chính xác 100% (`EXACT_MATCH`)** | **1** | 1.8% | B301 ("Lược sử thời gian" - Stephen Hawking, NXB Trẻ) |
| **Bìa chờ kiểm chứng ấn bản (`WAITING_VERIFICATION`)** | **2** | 3.6% | B201 (C++ Bách Khoa vs KH&KT), B002 (Sapiens Omega+ vs Harper) |
| **Bìa không thuộc danh mục DB (`UNMATCHED`)** | **53** | 94.6% | Các tựa sách NXB Trẻ, Kim Đồng, Xây dựng... không có trong 129 sách |
| **Bìa do AI tạo ra (AI Generated)** | **0** | **0%** | **Tuyệt đối 0% bìa AI; 100% là ảnh chụp/scan xuất bản thật** |

---

## 2. CHI TIẾT BÌA TÍCH HỢP THÀNH CÔNG (`EXACT_MATCH`)

### Đầu sách B301 — "Lược sử thời gian" (Stephen Hawking)
- **Mã sách trong DB:** `B301` (ID: `261`)
- **Tên sách:** Lược sử thời gian (A Brief History of Time)
- **Tác giả:** Stephen Hawking (Dịch giả: Cao Chi - Phạm Văn Thiều)
- **Nhà xuất bản:** NXB Trẻ (Năm XB: 2019, In lần thứ 30)
- **ISBN chính thức:** `978-604-1-01204-2` (Thuộc 11 ISBN đã xác minh)
- **File nguồn:** `storage/doi_soat/anh_sach/khoa_hoc/5471e6cd53f0f023bbf160915a54da7c.jpg.webp`
- **File triển khai trong hệ thống:**
  - `public/assets/book-covers/b301-luoc-su-thoi-gian.webp` (137,418 bytes, WebP 750x750)
  - `public/assets/book-covers/b301-luoc-su-thoi-gian.jpg` (208,825 bytes, JPEG fallback)
- **Cập nhật Database:** `UPDATE books SET cover_url = '/assets/book-covers/b301-luoc-su-thoi-gian.webp' WHERE id = 261;`
- **Kiểm thử hiển thị:**
  - `tests/audit_book_covers.php`: `usable_local_image = true`, `mime = image/webp`, `sha256 = 9f5ea52bfb909ef6345411e44f29dcbc77b36f2fd8c5245947d6f92bffdfe372`.
  - HTTP `GET /book/261` (port 8010): HTTP 200 OK, thẻ `<img>` bìa hiển thị chuẩn xác.

---

## 3. DANH MỤC ĐỐI CHIẾU CHI TIẾT 56 FILE TRONG BỘ ẢNH ĐỐI SOÁT

### 3.1. Thư mục `khoa_hoc` (14 files)

| STT | Tên file gốc | Tên sách nhận diện | Tác giả & Dịch giả | Nhà xuất bản | Trạng thái | Mã DB | Ghi chú & Lý do xử lý |
|---|---|---|---|---|---|---|---|
| 1 | `5471e6cd53f0f023bbf160915a54da7c.jpg.webp` | Lược sử thời gian | Stephen Hawking (Cao Chi, Phạm Văn Thiều dịch) | NXB Trẻ | **EXACT_MATCH** | **B301** | **Khớp chính xác 100% tên, tác giả, dịch giả, NXB. Đã tích hợp vào hệ thống.** |
| 2 | `2e0daae3f9383a3e1c5d85b1e0156953.jpg` | Sapiens: Lược sử loài người | Yuval Noah Harari (Nguyễn Thủy Chung dịch) | Omega+ / NXB Tri Thức | `WAITING_VERIFICATION` | B002 | Sách B002 trong DB ghi nhận ấn bản gốc Harper (ISBN 9780062316097) đã có bìa OpenLibrary chính thức. Không ép thay để giữ nhất quán dữ liệu metadata. |
| 3 | `sach-dom-xanh-mo-p274242089.html` | Đốm xanh mờ (Pale Blue Dot) | Carl Sagan (Nguyễn Việt Long dịch) | NXB Thế Giới | `UNMATCHED` | NONE | Sách của Carl Sagan nhưng khác tựa sách trong DB (B303 là "Vũ trụ" / Cosmos - NXB Tri Thức). Tuyệt đối không gán nhầm. |
| 4 | `1fb3dbf2-1cee-4099-8d86-a980720b9a9a.webp` | Bí kíp rèn luyện tính tự giác | Mengbao Culture (Thanh Vân dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Tựa sách thiếu nhi giáo dục không có trong danh mục 129 sách. |
| 5 | `54664066-ea53-4cc7-a886-a3e1b58d08af.webp` | Kĩ năng cho HS tiểu học: Rèn cách quản lí thời gian | Liu Yong (Hoàng Phương Thuý dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 6 | `620b5687-41ce-4f06-aede-261c3bcb8696.webp` | Kĩ năng cho HS tiểu học: Rèn năng lực ngôn từ | Liu Yong (Hoàng Phương Thuý dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 7 | `78a795c3-4b13-4c65-aa84-77d4834cc93e.webp` | Khéo khôn với tiền: Hiểu về đầu tư tài chính | Lê Thị Thuý Sen (Thăng Fly vẽ) | NXB Kim Đồng | `UNMATCHED` | NONE | Bộ truyện tranh tài chính Kim Đồng, không có trong danh mục DB. |
| 8 | `87098cf1-816b-4e6d-8617-ed36a7af1e11.webp` | MBTI: Hiểu tính cách để học giỏi hơn 4 | Jo Su Yeon (Thùy Ngân dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 9 | `ac5c82a6-6fb0-45f2-ac1d-9de3da5514c8.webp` | Bí kíp vượt qua áp lực học hành | Mengbao Culture (Thanh Vân dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 10 | `cam-nang-sinh-hoat-bang-tranh...webp` | Cẩm nang sinh hoạt bằng tranh cho bé 2 | Masaaki Yatagai, Akira Murakoshi | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 11 | `comic-ki-nang-song-thoat-hiem-an-toan...webp` | Comic kĩ năng sống: Thoát hiểm an toàn | Hoài Thu, Hiếu Minh, Nguyễn Quang Toàn | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 12 | `ebdf3925-2f50-4e67-a513-d2999ca02d08.webp` | Kĩ năng cho HS tiểu học: Vượt qua nghịch cảnh | Liu Yong (Hoàng Phương Thuý dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 13 | `f5ab9af4-ab38-4093-8272-29e88a23cfb8.webp` | MBTI: Hiểu tính cách để chọn đúng nghề nghiệp 5 | Jo Su Yeon (Thùy Ngân dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 14 | `hieu-ve-tai-chinh...tiet-kiem...webp` | Hiểu về tài chính: Tiết kiệm cho tương lai | Cecilia Minden (Hoàng Thi dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |

---

### 3.2. Thư mục `tin_hoc` (11 files)

| STT | Tên file gốc | Tên sách nhận diện | Tác giả & Dịch giả | Nhà xuất bản | Trạng thái | Mã DB | Ghi chú & Lý do xử lý |
|---|---|---|---|---|---|---|---|
| 15 | `8935095633340.jpg` | Giáo trình C++ & Lập trình hướng đối tượng | GS. Phạm Văn Ất, Lê Trường Thông | NXB Bách Khoa Hà Nội | `WAITING_VERIFICATION` | B201 | Sách B201 trong DB là "Kỹ thuật Lập trình C/C++" do NXB Khoa học & Kỹ thuật xuất bản. Cùng chủ đề nhưng khác NXB/ấn bản; giữ nguyên placeholder trung tính. |
| 16 | `116749.jpg` | Mạng máy tính Tập 1 | Tống Văn On | NXB Thống kê | `UNMATCHED` | B207 | Sách B207 trong DB là "Mạng máy tính và truyền thông số liệu" của TS. Nguyễn Hồng Sơn, NXB Bưu điện. Khác tác giả, khác giáo trình. |
| 17 | `142769.jpg` | Sổ tay HTML & JavaScript | Nguyễn Trường Sinh (Chủ biên) | NXB Lao Động Xã Hội | `UNMATCHED` | B008 | Sách B008 trong DB là "HTML & CSS" của Jon Duckett (Wiley, OpenLibrary cover). Khác hoàn toàn. |
| 18 | `8935074130884.jpg` | Công thức & Hàm Excel | VN-Guide / Ngọc Chi | NXB Thanh Hóa | `UNMATCHED` | B807 | Sách B807 trong DB là "Excel Ứng dụng trong Kế toán..." của ThS. Lê Hữu Lương, NXB Thống kê. Khác tác giả và NXB. |
| 19 | `8935217115532.jpg` | Cấu trúc dữ liệu và thuật toán C/C++ Tập 2 | Trần Thông Quế | NXB TT&TT | `UNMATCHED` | B202 | Sách B202 trong DB là giáo trình của Đỗ Xuân Lôi, ĐHQG Hà Nội. Khác tác giả. |
| 20 | `8935217119059.jpg` | Lập trình Python từ cơ bản đến nâng cao | Trần Thông Quế | NXB TT&TT | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 21 | `8935235230804.jpg` | Tớ học lập trình Scratch | Rosie Dickins et al. | Nhã Nam / Thế Giới | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 22 | `8936230474507.jpg` | Tuyệt chiêu kiếm tiền bằng AI | Ngô Chấn Thái | 1980 Books / Công Thương | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 23 | `9786048229177.jpg` | Chinh phục trình diễn bằng PowerPoint | TS. Tống Xuân Tám | NXB Xây dựng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 24 | `9786048269630.jpg` | Tin học ứng dụng 2 SAP2000 | ThS. Nguyễn Vy Thanh | NXB Xây dựng | `UNMATCHED` | NONE | Giáo trình xây dựng, không có trong danh mục DB. |
| 25 | `9786048271916.png` | Lập trình Java căn bản | Phạm Văn Trung et al. | NXB Xây dựng | `UNMATCHED` | NONE | Giáo trình NXB Xây dựng, không có trong danh mục DB. |

---

### 3.3. Thư mục `kinh_te` (13 files — 100% từ NXB Trẻ)

| STT | Tên file gốc | Tên sách nhận diện | Tác giả & Dịch giả | Nhà xuất bản | Trạng thái | Mã DB | Ghi chú & Lý do xử lý |
|---|---|---|---|---|---|---|---|
| 26 | `copy_16_nxbtre_thumb_21112019_111109.jpg` | Dốc hết trái tim (Pour Your Heart Into It) | Howard Schultz (Võ Công Hùng dịch) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 27 | `nxbtre_thumb_03142026_021449.jpg` | Giấc mơ phá kỷ lục Champions League | Carlo Ancelotti & Chris Brady | NXB Trẻ | `UNMATCHED` | NONE | Hồi ký thể thao, không có trong danh mục DB. |
| 28 | `nxbtre_thumb_04132026_031337.jpg` | 500 Câu hỏi Tại sao Thế nào: Động vật 1 | Sophie de Mullenheim | NXB Trẻ | `UNMATCHED` | NONE | Sách khoa học thiếu nhi (đặt nhầm thư mục), không có trong DB. |
| 29 | `nxbtre_thumb_04312026_113158.jpg` | Nhượng quyền khởi nghiệp (Franchise) | Nguyễn Phi Vân | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 30 | `nxbtre_thumb_07022026_090259.jpg` | Từ bỏ để tự do (Quitting: A Life Strategy) | TS. Julia Keller (Nguyễn Đức Quang dịch) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 31 | `nxbtre_thumb_08202025_082040.jpg` | Đừng bao giờ lãnh đạo một mình | Keith Ferrazzi, Paul Hill | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 32 | `nxbtre_thumb_08452025_084511.jpg` | Làm ít được nhiều (Great at Work) | Morten T. Hansen | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 33 | `nxbtre_thumb_13562026_015640.jpg` | Quyền lực hướng thiện (Good Power) | Ginni Rometty (Trần Thị Ngân Tuyền dịch) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 34 | `nxbtre_thumb_15302026_103024.jpg` | Tư duy đầu nguồn (Upstream) | Dan Heath (Lan Anh dịch) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 35 | `nxbtre_thumb_15372026_103701.jpg` | Thương hiệu bước qua thao túng để chữa lành | Nguyễn Khoa Hồng Thành | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 36 | `nxbtre_thumb_24362025_093634.jpg` | Năm tính cách tiền bạc | Taylor & Megan Kovar (Huyền Trân dịch) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 37 | `nxbtre_thumb_24392026_113944.jpg` | Nghề truyền thông thị giác | Phan Trọng Bình (Bưởi) | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 38 | `nxbtre_thumb_29102025_041022.jpg` | Tỷ phú nhà bên làm gì sau 5 giờ chiều? | Shimamura Yoshihiro | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |

---

### 3.4. Thư mục `thieu_nhi` (11 files)

| STT | Tên file gốc | Tên sách nhận diện | Tác giả & Dịch giả | Nhà xuất bản | Trạng thái | Mã DB | Ghi chú & Lý do xử lý |
|---|---|---|---|---|---|---|---|
| 39 | `1af1d946-7619-4c27-bdc0-5156181367cf.jpg` | Cổ tích: Cô bé Lọ Lem | Hiếu Minh kể / Cloud Pillow Studio | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 40 | `20059183-d57e-4dda-ac8f-89d33e06601f.webp` | Hạt giống bay bồng bềnh | Mary Auld / Dawn Cooper | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 41 | `4da9362b-869d-4969-b3ee-bdd7b2627959.jpg` | Cổ tích: Bà Chúa Tuyết | Phương Thúy kể / Cloud Pillow Studio | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 42 | `58b95a79-8de9-4650-b588-1bb8760082a2.webp` | Cổ tích: Bộ quần áo mới của hoàng đế | Hiếu Minh kể / Cloud Pillow Studio | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 43 | `8277c970-2ec6-4887-a8e7-63a40781765f.jpg` | Bà ngoại trên cây táo | Mira Lobe / Chu Thu Phương dịch | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 44 | `dfe8afd1-fdfd-40a0-a7c4-a41d79b5cfd7.jpg` | Cổ tích: Chó sói và bảy chú dê con | Hiếu Minh kể / Cloud Pillow Studio | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 45 | `ho-cach-tro-chuyen-bia-tb3-final...webp` | 90% Trẻ thông minh nhờ cách trò chuyện | Urako Kanamori (Phạm Lê Dạ Hương dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 46 | `nxbtre_thumb_06422026_044241.jpg` | Hành trình khám phá: Mây | Thanh Hà / Phạm Cương vẽ | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 47 | `nxbtre_thumb_31492026_044918.jpg` | Cá voi và cá heo có thông minh hơn con người? | Eliza Jeffery / Lays Bittencourt | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 48 | `nxbtre_thumb_31552026_045506.jpg` | Rắn có biết trước động đất không? | Eliza Jeffery / Denis Alonso | NXB Trẻ | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 49 | `thu-thi-cung-con-tinh-yeu-to-lon...webp` | Thủ thỉ cùng con: Tình yêu to lớn | Emma Dodd (Khôi Nguyên dịch) | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |

---

### 3.5. Thư mục `van_hoc` (7 files)

| STT | Tên file gốc | Tên sách nhận diện | Tác giả & Dịch giả | Nhà xuất bản | Trạng thái | Mã DB | Ghi chú & Lý do xử lý |
|---|---|---|---|---|---|---|---|
| 50 | `0b8ab253-62dd-41a8-8a09-e986dabcfabc.webp` | Tôi đã trở thành nhà văn như thế nào | Phùng Quán | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 51 | `898250bb-ddfe-4ac5-99b9-30457cc61e92.jpg` | Biệt đội chó bay | Huỳnh Long, Mai Chi | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 52 | `b0535f46-0598-4b0d-97e5-39ece5d8a86b.webp` | Nguyễn Thái Học | Lê Minh Quốc | NXB Kim Đồng | `UNMATCHED` | NONE | Truyện tranh lịch sử, không có trong danh mục DB. |
| 53 | `cay-bang-vuong-ke-chuyen-bia.jpg` | Cây bàng vuông kể chuyện | Phạm Duy Nghĩa | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 54 | `d899856e-d185-43f2-96f8-9353afb63469.jpg` | Cỏ lưu lạc | Bùi Tiểu Quyên | NXB Kim Đồng | `UNMATCHED` | NONE | Không có trong danh mục DB. |
| 55 | `van-hoc-trong-nha-truong-ha-noi...jpg` | Hà Nội băm sáu phố phường | Thạch Lam | NXB Kim Đồng | `UNMATCHED` | NONE | Ấn bản Kim Đồng, không có trong danh mục DB. |
| 56 | `nguoi-co-duyen-voi-ho.htm` | Người có duyên với hổ | Nguyễn Hồng Chiến (ISBN 978-604-2-42428-8) | NXB Kim Đồng | `UNMATCHED` | NONE | Trang web NXB Kim Đồng, không có trong danh mục DB. |

---

## 4. KẾT LUẬN & KIẾN NGHỊ

1. **Tuân thủ đạo đức dữ liệu thư viện:**
   - Chỉ duy nhất đầu sách **B301 ("Lược sử thời gian" - Stephen Hawking, NXB Trẻ)** có ảnh bìa đúng 100% cả về tiêu đề, tác giả, dịch giả và nhà xuất bản, đã được tích hợp trực tiếp vào hệ thống.
   - 53 đầu sách còn lại trong bộ ảnh KHÔNG thuộc danh mục 129 sách hiện tại của Paper Haven hoặc thuộc ấn bản/NXB khác. Hệ thống kiên quyết **KHÔNG gán ép, KHÔNG lấy râu ông nọ cắm cằm bà kia**.
   - Đối với các đầu sách chưa có bìa ảnh thật đã được xác minh ấn bản, hệ thống tiếp tục áp dụng **placeholder SVG trung tính chuẩn thư viện** (theo danh mục thể loại và tông màu nhận diện), bảo đảm giao diện sang trọng, chuyên nghiệp và trung thực.

2. **Dự án Laravel tiếp theo:**
   - 53 tựa sách thật từ NXB Trẻ và NXB Kim Đồng trong bộ ảnh này có thể được bổ sung làm danh mục đầu sách mới khi xây dựng đồ án Laravel, đảm bảo có sẵn bìa thật chính thức ngay từ đầu.
