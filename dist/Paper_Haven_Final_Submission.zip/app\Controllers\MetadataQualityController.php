<?php
declare(strict_types=1);

namespace Library\Controllers;

use Library\Core\Database;

final class MetadataQualityController extends Controller
{
    public function index(): void
    {
        require_permission('books.view');
        $db = Database::connection();

        $filter = (string) ($_GET['filter'] ?? 'all');
        $search = trim((string) ($_GET['q'] ?? ''));

        // Overall stats
        $totalBooks = (int) $db->query('SELECT COUNT(*) FROM books')->fetchColumn();
        $publicBooks = (int) $db->query('SELECT COUNT(*) FROM books WHERE is_public = 1')->fetchColumn();
        $withIsbn = (int) $db->query("SELECT COUNT(*) FROM books WHERE isbn IS NOT NULL AND TRIM(isbn) != '' AND isbn NOT LIKE 'EBOOK-%'")->fetchColumn();
        $missingIsbn = (int) $db->query("SELECT COUNT(*) FROM books WHERE isbn IS NULL OR TRIM(isbn) = '' OR isbn LIKE 'EBOOK-%'")->fetchColumn();
        $missingCover = (int) $db->query('SELECT COUNT(*) FROM books WHERE cover_url IS NULL OR TRIM(cover_url) = ""')->fetchColumn();
        $missingDesc = (int) $db->query('SELECT COUNT(*) FROM books WHERE description IS NULL OR CHAR_LENGTH(TRIM(description)) < 40')->fetchColumn();
        $missingPublisher = (int) $db->query('SELECT COUNT(*) FROM books WHERE publisher IS NULL OR TRIM(publisher) = ""')->fetchColumn();
        
        $zeroCopies = (int) $db->query('
            SELECT COUNT(*) FROM books b 
            WHERE NOT EXISTS (SELECT 1 FROM book_copies bc WHERE bc.book_id = b.id)
        ')->fetchColumn();

        // Calculate completeness score (%)
        $totalCopies = (int) $db->query('SELECT COUNT(*) FROM book_copies')->fetchColumn();
        $scoreIsbn = $totalBooks > 0 ? ($withIsbn / $totalBooks) * 25 : 0;
        $scoreCover = $totalBooks > 0 ? (($totalBooks - $missingCover) / $totalBooks) * 20 : 0;
        $scoreDesc = $totalBooks > 0 ? (($totalBooks - $missingDesc) / $totalBooks) * 25 : 0;
        $scorePub = $totalBooks > 0 ? (($totalBooks - $missingPublisher) / $totalBooks) * 15 : 0;
        $scoreCopies = $totalBooks > 0 ? (($totalBooks - $zeroCopies) / $totalBooks) * 15 : 0;
        $completenessScore = (int) round($scoreIsbn + $scoreCover + $scoreDesc + $scorePub + $scoreCopies);

        // Duplicate ISBN check
        $dupStmt = $db->query("
            SELECT isbn, COUNT(*) as cnt 
            FROM books 
            WHERE isbn IS NOT NULL AND TRIM(isbn) != '' AND isbn NOT LIKE 'EBOOK-%'
            GROUP BY isbn 
            HAVING cnt > 1
        ");
        $duplicateIsbns = $dupStmt->fetchAll(\PDO::FETCH_ASSOC);

        // Query books with filter
        $query = "
            SELECT b.id, b.book_code, b.title, b.author, b.isbn, b.publisher, b.publication_year, 
                   b.description, b.cover_url, b.is_public, c.name as category_name,
                   (SELECT COUNT(*) FROM book_copies bc WHERE bc.book_id = b.id) as copies_count,
                   (SELECT COUNT(*) FROM book_copies bc WHERE bc.book_id = b.id AND bc.status = 'available') as available_count
            FROM books b
            LEFT JOIN categories c ON b.category_id = c.id
            WHERE 1=1
        ";
        $params = [];

        if ($search !== '') {
            $query .= " AND (b.title LIKE ? OR b.author LIKE ? OR b.book_code LIKE ? OR b.isbn LIKE ?)";
            $term = '%' . $search . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        if ($filter === 'missing_isbn') {
            $query .= " AND (b.isbn IS NULL OR TRIM(b.isbn) = '' OR b.isbn LIKE 'EBOOK-%')";
        } elseif ($filter === 'missing_cover') {
            $query .= " AND (b.cover_url IS NULL OR TRIM(b.cover_url) = '')";
        } elseif ($filter === 'missing_desc') {
            $query .= " AND (b.description IS NULL OR CHAR_LENGTH(TRIM(b.description)) < 40)";
        } elseif ($filter === 'zero_copies') {
            $query .= " AND NOT EXISTS (SELECT 1 FROM book_copies bc WHERE bc.book_id = b.id)";
        } elseif ($filter === 'demo') {
            $query .= " AND b.book_code LIKE 'DEMO-%'";
        } elseif ($filter === 'duplicate_isbn') {
            $query .= " AND b.isbn IN (SELECT isbn FROM books WHERE isbn IS NOT NULL AND TRIM(isbn) != '' AND isbn NOT LIKE 'EBOOK-%' GROUP BY isbn HAVING COUNT(*) > 1)";
        }

        $query .= " ORDER BY b.id DESC LIMIT 150";
        $stmt = $db->prepare($query);
        $stmt->execute($params);
        $books = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $this->render('admin/metadata_quality', [
            'title' => 'Kiểm toán chất lượng Metadata',
            'totalBooks' => $totalBooks,
            'publicBooks' => $publicBooks,
            'withIsbn' => $withIsbn,
            'missingIsbn' => $missingIsbn,
            'missingCover' => $missingCover,
            'missingDesc' => $missingDesc,
            'missingPublisher' => $missingPublisher,
            'zeroCopies' => $zeroCopies,
            'totalCopies' => $totalCopies,
            'completenessScore' => $completenessScore,
            'duplicateIsbns' => $duplicateIsbns,
            'books' => $books,
            'filter' => $filter,
            'search' => $search,
        ]);
    }
}
