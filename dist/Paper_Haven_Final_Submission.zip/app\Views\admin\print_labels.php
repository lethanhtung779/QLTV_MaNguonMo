<div class="panel-header no-print">
  <div>
    <a class="back-link" href="<?= e(url('/admin/books/' . (int) $book['id'] . '/copies')) ?>">← Quay lại danh sách bản sao</a>
    <span class="eyebrow">IN TEM NHÃN MÃ VẠCH & QR</span>
    <h1><?= e($book['title']) ?></h1>
    <p>In nhãn dán gáy sách hoặc bìa trong cho <?= count($copies) ?> bản sao của đầu sách này.</p>
  </div>
  <div>
    <button class="button button-primary" onclick="window.print()">In tất cả tem nhãn (Print) 🖨</button>
  </div>
</div>

<style>
.label-sheet {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
  margin-top: 1.5rem;
}
.book-label-card {
  border: 2px dashed #193E30;
  border-radius: 8px;
  padding: 1.25rem;
  background: #fff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  text-align: center;
  box-shadow: 0 2px 6px rgba(0,0,0,0.05);
}
.label-library {
  font-size: 0.8rem;
  font-weight: 700;
  color: #193E30;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  border-bottom: 1px solid #E8D8C5;
  padding-bottom: 0.35rem;
  margin-bottom: 0.5rem;
}
.label-title {
  font-size: 0.95rem;
  font-weight: 600;
  color: #302B25;
  margin: 0.25rem 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.label-codes {
  display: flex;
  justify-content: space-around;
  align-items: center;
  gap: 1rem;
  margin: 0.75rem 0;
}
.label-barcode {
  flex: 1;
}
.label-barcode img {
  max-width: 100%;
  height: 50px;
}
.label-qr img {
  width: 70px;
  height: 70px;
}
.label-footer {
  display: flex;
  justify-content: space-between;
  font-size: 0.8rem;
  color: #74685c;
  border-top: 1px solid #E8D8C5;
  padding-top: 0.35rem;
}
@media print {
  .no-print, .staff-sidebar, .staff-header {
    display: none !important;
  }
  .staff-shell, .staff-main {
    margin: 0 !important;
    padding: 0 !important;
  }
  .label-sheet {
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 1cm !important;
  }
  .book-label-card {
    border: 1px solid #000 !important;
    page-break-inside: avoid;
    box-shadow: none !important;
  }
}
</style>

<div class="label-sheet">
  <?php foreach ($copies as $copy): ?>
    <div class="book-label-card">
      <div class="label-library">THƯ VIỆN PAPER HAVEN</div>
      <div class="label-title"><?= e($book['title']) ?></div>
      
      <div class="label-codes">
        <div class="label-barcode">
          <img src="<?= e(url('/barcode/' . rawurlencode($copy['copy_code']))) ?>" alt="Barcode <?= e($copy['copy_code']) ?>">
        </div>
        <div class="label-qr">
          <img src="<?= e(url('/qr/' . rawurlencode($copy['copy_code']))) ?>" alt="QR <?= e($copy['copy_code']) ?>">
        </div>
      </div>

      <div class="label-footer">
        <span>Bản sao: <strong><?= e($copy['copy_code']) ?></strong></span>
        <span>Kệ: <strong><?= e($copy['shelf_location'] ?: 'Chưa gán') ?></strong></span>
      </div>
    </div>
  <?php endforeach; ?>
</div>
