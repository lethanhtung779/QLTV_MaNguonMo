<div class="panel-header">
  <div>
    <span class="eyebrow">QUẢN LÝ KHO SÁCH</span>
    <h1>Kiểm kê thư viện</h1>
    <p>Tổ chức các đợt kiểm kê sách, đối soát số lượng thực tế với hệ thống, phát hiện sách mất, thiếu hoặc sai vị trí kệ.</p>
  </div>
</div>

<div class="stats-grid" style="display: grid; grid-template-columns: 1fr 2fr; gap: 2rem; margin-bottom: 2rem;">
  <!-- Create new audit session -->
  <section class="admin-section" style="background: #fff; padding: 1.5rem; border-radius: 8px; border: 1px solid #E8D8C5; height: fit-content;">
    <div class="section-heading">
      <div>
        <span class="eyebrow">TẠO ĐỢT MỚI</span>
        <h3>Bắt đầu đợt kiểm kê</h3>
      </div>
    </div>
    <form action="<?= e(url('/admin/inventory/audits')) ?>" method="post" class="form-stack">
      <?= csrf_field() ?>
      <label>
        Tên đợt kiểm kê *
        <input type="text" name="title" required placeholder="VD: Kiểm kê định kỳ Quý 4/2026">
      </label>
      <label>
        Phạm vi kiểm kê
        <select name="scope">
          <option value="all">Toàn bộ kho sách thư viện</option>
          <option value="zone_a">Khu A - Sách Văn học & Nghệ thuật</option>
          <option value="zone_b">Khu B - Sách Khoa học & Công nghệ</option>
          <option value="zone_c">Khu C - Sách Lịch sử & Xã hội</option>
        </select>
      </label>
      <label>
        Ghi chú / Kế hoạch
        <textarea name="notes" rows="3" placeholder="Ghi chú nhân sự hoặc khu vực ưu tiên..."></textarea>
      </label>
      <button class="button button-primary" type="submit">Bắt đầu đợt kiểm kê <span>→</span></button>
    </form>
  </section>

  <!-- List of audit sessions -->
  <section class="admin-section" style="background: #fff; padding: 1.5rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <div class="section-heading">
      <div>
        <span class="eyebrow">LỊCH SỬ KIỂM KÊ</span>
        <h3>Các đợt kiểm kê đã tạo (<?= count($audits) ?>)</h3>
      </div>
    </div>
    <?php if ($audits): ?>
      <div class="table-wrap">
        <table class="data-table" style="width: 100%;">
          <thead>
            <tr>
              <th>Mã đợt</th>
              <th>Tiêu đề</th>
              <th>Dự kiến / Đã quét</th>
              <th>Trạng thái</th>
              <th>Ngày tạo</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($audits as $audit): ?>
              <tr>
                <td><strong><?= e($audit['audit_code']) ?></strong></td>
                <td>
                  <strong><?= e($audit['title']) ?></strong>
                  <br><small style="color: #74685c;">Người tạo: <?= e($audit['starter_name']) ?></small>
                </td>
                <td>
                  <span style="font-weight: 600; color: #193E30;"><?= (int) $audit['total_scanned'] ?></span> / <?= (int) $audit['total_expected'] ?>
                  <?php if ((int) $audit['total_missing'] > 0 && $audit['status'] === 'completed'): ?>
                    <small style="color: #dc3545; display: block;">Thiếu: <?= (int) $audit['total_missing'] ?></small>
                  <?php endif; ?>
                </td>
                <td>
                  <span class="status-badge <?= $audit['status'] === 'completed' ? 'badge-success' : 'badge-warning' ?>">
                    <?= e(['in_progress'=>'Đang kiểm kê','completed'=>'Đã hoàn tất','pending_approval'=>'Chờ duyệt','cancelled'=>'Đã hủy'][$audit['status']] ?? $audit['status']) ?>
                  </span>
                </td>
                <td><?= e(date('d/m/Y', strtotime($audit['started_at']))) ?></td>
                <td>
                  <a class="button button-primary button-small" href="<?= e(url('/admin/inventory/audits/' . (int) $audit['id'])) ?>">
                    <?= $audit['status'] === 'completed' ? 'Xem biên bản' : 'Quét sách →' ?>
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="empty-state" style="padding: 2rem; text-align: center; background: #F8F3EB; border-radius: 6px;">
        <span style="font-size: 2rem;">✓</span>
        <h4 style="margin: 0.5rem 0 0; color: #193E30;">Chưa có đợt kiểm kê nào</h4>
        <p style="color: #74685c;">Hãy tạo đợt kiểm kê đầu tiên ở cột bên trái để bắt đầu quét đối chiếu kho sách.</p>
      </div>
    <?php endif; ?>
  </section>
</div>
