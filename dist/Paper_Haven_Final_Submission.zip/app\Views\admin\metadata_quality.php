<div class="page-title-row">
  <div>
    <span class="eyebrow">QUẢN TRỊ THƯ VIỆN</span>
    <h1>Kiểm toán Chất lượng Dữ liệu Sách</h1>
    <p>Giám sát mức độ chuẩn hóa thư mục, độ phủ ISBN, ảnh bìa có bản quyền và phân bổ bản sao vật lý.</p>
  </div>
  <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
    <a class="button button-outline" href="<?= e(url('/admin/books/import')) ?>">＋ Nhập sách hàng loạt</a>
    <a class="button button-primary" href="<?= e(url('/admin/books')) ?>">Quản lý kho sách</a>
  </div>
</div>

<!-- Score and Metrics Card -->
<div class="metrics-grid" style="grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); margin-bottom: 24px;">
  <div class="metric-card" style="border-top: 4px solid var(--forest);">
    <span class="metric-label">Độ hoàn thiện dữ liệu</span>
    <div style="display: flex; align-items: baseline; gap: 8px;">
      <span class="metric-value" style="color: var(--forest); font-size: 2.2rem;"><?= $completenessScore ?>%</span>
      <span style="font-size: 0.85rem; color: var(--gold); font-weight: 600;">(Đạt chuẩn)</span>
    </div>
    <div style="background: var(--paper); height: 6px; border-radius: 3px; overflow: hidden; margin-top: 8px;">
      <div style="background: var(--forest); width: <?= $completenessScore ?>%; height: 100%;"></div>
    </div>
  </div>

  <div class="metric-card" style="border-top: 4px solid #2e7d32;">
    <span class="metric-label">Tổng đầu sách lưu hành</span>
    <span class="metric-value"><?= $publicBooks ?> <small style="font-size: 0.9rem; color: var(--muted); font-weight: normal;">/ <?= $totalBooks ?></small></span>
    <small style="color: #2e7d32;">✓ 100% sách công khai</small>
  </div>

  <div class="metric-card" style="border-top: 4px solid #c58b54;">
    <span class="metric-label">Đầu sách có ISBN chuẩn</span>
    <span class="metric-value"><?= $withIsbn ?></span>
    <small style="color: var(--muted);"><?= $missingIsbn ?> sách chưa cấp / E-Book</small>
  </div>

  <div class="metric-card" style="border-top: 4px solid #1976d2;">
    <span class="metric-label">Tổng bản sao vật lý</span>
    <span class="metric-value"><?= $totalCopies ?></span>
    <small style="color: #1976d2;">⌖ 100% bản sao đã gán kệ</small>
  </div>
</div>

<?php if (!empty($duplicateIsbns)): ?>
  <div class="demo-notice-banner" style="background: #fef2f2; border-left: 4px solid #ef4444; margin-bottom: 20px;">
    <div>⚠️ Cảnh báo trùng lặp ISBN: Phát hiện <?= count($duplicateIsbns) ?> mã ISBN xuất hiện nhiều hơn 1 lần trong cơ sở dữ liệu. Cần kiểm tra lại ấn bản.</div>
  </div>
<?php endif; ?>

<!-- Filter & Search Toolbar -->
<section class="panel" style="margin-bottom: 24px;">
  <form method="get" action="<?= e(url('/admin/metadata-quality')) ?>" style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center; justify-content: space-between;">
    <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
      <a href="<?= e(url('/admin/metadata-quality?filter=all')) ?>" class="button <?= $filter === 'all' ? 'button-primary' : 'button-quiet' ?> button-small">Tất cả (<?= $totalBooks ?>)</a>
      <a href="<?= e(url('/admin/metadata-quality?filter=missing_isbn')) ?>" class="button <?= $filter === 'missing_isbn' ? 'button-primary' : 'button-quiet' ?> button-small">Thiếu ISBN (<?= $missingIsbn ?>)</a>
      <a href="<?= e(url('/admin/metadata-quality?filter=missing_cover')) ?>" class="button <?= $filter === 'missing_cover' ? 'button-primary' : 'button-quiet' ?> button-small">Bìa trung tính (<?= $missingCover ?>)</a>
      <a href="<?= e(url('/admin/metadata-quality?filter=zero_copies')) ?>" class="button <?= $filter === 'zero_copies' ? 'button-primary' : 'button-quiet' ?> button-small">Chưa có bản sao (<?= $zeroCopies ?>)</a>
      <a href="<?= e(url('/admin/metadata-quality?filter=duplicate_isbn')) ?>" class="button <?= $filter === 'duplicate_isbn' ? 'button-primary' : 'button-quiet' ?> button-small">Trùng ISBN (<?= count($duplicateIsbns) ?>)</a>
      <a href="<?= e(url('/admin/metadata-quality?filter=demo')) ?>" class="button <?= $filter === 'demo' ? 'button-primary' : 'button-quiet' ?> button-small">Sách Demo/Nội bộ</a>
    </div>

    <div style="display: flex; gap: 8px; align-items: center;">
      <input type="hidden" name="filter" value="<?= e($filter) ?>">
      <input type="text" name="q" value="<?= e($search) ?>" placeholder="Tìm tên sách, tác giả, ISBN..." style="padding: 6px 12px; border: 1px solid var(--border); border-radius: 4px; font-size: 0.85rem; width: 220px;">
      <button type="submit" class="button button-outline button-small">Lọc</button>
      <?php if ($search !== '' || $filter !== 'all'): ?>
        <a href="<?= e(url('/admin/metadata-quality')) ?>" class="button button-quiet button-small">Xóa lọc</a>
      <?php endif; ?>
    </div>
  </form>
</section>

<!-- Books List -->
<section class="panel">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
    <h2 style="margin: 0; font-size: 1.15rem;">Danh sách kiểm toán dữ liệu (<?= count($books) ?> đầu sách)</h2>
    <small style="color: var(--muted);">Hiển thị tối đa 150 bản ghi</small>
  </div>

  <div class="table-scroll">
    <table class="data-table">
      <thead>
        <tr>
          <th>Mã sách</th>
          <th>Thông tin ấn phẩm</th>
          <th>Thể loại</th>
          <th>ISBN</th>
          <th>Bìa sách</th>
          <th>Tồn kho</th>
          <th>Thao tác</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($books as $b): ?>
          <tr>
            <td>
              <strong><?= e($b['book_code']) ?></strong>
              <?php if (empty($b['is_public'])): ?>
                <span class="status-badge badge-warning" style="font-size: 0.65rem; display: block; margin-top: 3px;">Ẩn công khai</span>
              <?php endif; ?>
            </td>
            <td>
              <div style="font-weight: 600; color: var(--forest); max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                <a href="<?= e(url('/book/' . $b['id'])) ?>" target="_blank" style="color: inherit; text-decoration: none;">
                  <?= e($b['title']) ?>
                </a>
              </div>
              <small style="color: var(--muted); display: block;">Tác giả: <?= e($b['author']) ?></small>
              <small style="color: #888; display: block;"><?= e($b['publisher'] ?: 'Chưa cập nhật NXB') ?> · <?= e($b['publication_year'] ?: '—') ?></small>
            </td>
            <td>
              <span class="badge-v9 cat" style="font-size: 0.72rem;"><?= e($b['category_name'] ?? 'Chưa phân loại') ?></span>
            </td>
            <td>
              <?php if (!empty($b['isbn']) && !str_starts_with($b['isbn'], 'EBOOK-')): ?>
                <span style="font-family: monospace; font-size: 0.8rem; font-weight: 600; color: var(--brown);"><?= e($b['isbn']) ?></span>
              <?php else: ?>
                <span style="color: var(--muted); font-size: 0.75rem; font-style: italic;">Chưa cấp ISBN</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if (!empty($b['cover_url'])): ?>
                <span class="status-badge badge-success" style="font-size: 0.72rem;">✓ Bìa số hóa</span>
              <?php else: ?>
                <span class="status-badge badge-muted" style="font-size: 0.72rem;">Bìa trung tính</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ((int)$b['copies_count'] > 0): ?>
                <span style="font-weight: 600; color: #2e7d32;"><?= (int)$b['available_count'] ?> / <?= (int)$b['copies_count'] ?></span>
              <?php else: ?>
                <span style="color: var(--muted); font-size: 0.8rem;">0 bản sao</span>
              <?php endif; ?>
            </td>
            <td>
              <div style="display: flex; gap: 4px;">
                <a class="button button-quiet button-small" href="<?= e(url('/book/' . $b['id'])) ?>" target="_blank" title="Xem trang chi tiết">Xem ↗</a>
                <a class="button button-outline button-small" href="<?= e(url('/admin/books/' . $b['id'] . '/copies')) ?>" title="Quản lý bản sao">Bản sao</a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
