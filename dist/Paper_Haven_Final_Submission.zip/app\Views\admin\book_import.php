<div class="page-title-row">
  <div>
    <span class="eyebrow">QUẢN TRỊ KHO SÁCH</span>
    <h1>Nhập Sách Hàng Loạt An Toàn</h1>
    <p>Hỗ trợ nhập danh sách qua tệp CSV hoặc dán trực tiếp. Cơ chế xem trước và giao dịch (Transaction) chống trùng lặp.</p>
  </div>
  <div>
    <a class="button button-outline" href="<?= e(url('/admin/metadata-quality')) ?>">← Quay lại Chất lượng Metadata</a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="demo-notice-banner" style="background: #fef2f2; border-left: 4px solid #ef4444; margin-bottom: 24px;">
    <div>
      <strong>Đã phát hiện lỗi:</strong>
      <ul style="margin: 6px 0 0; padding-left: 20px;">
        <?php foreach ($errors as $err): ?>
          <li><?= e($err) ?></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
<?php endif; ?>

<?php if (empty($previewItems)): ?>
  <!-- Upload / Input Form -->
  <section class="panel">
    <form class="form-stack" method="post" action="<?= e(url('/admin/books/import/preview')) ?>" enctype="multipart/form-data">
      <?= csrf_field() ?>

      <div class="form-grid">
        <label>
          Thể loại mặc định (nếu trong dòng không ghi)
          <select name="default_category_id" required>
            <?php foreach ($categories as $cat): ?>
              <option value="<?= (int) $cat['id'] ?>"><?= e($cat['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </label>

        <label>
          Số bản sao tạo mặc định cho mỗi đầu sách
          <input type="number" name="default_copies" value="2" min="1" max="10" required>
        </label>

        <label>
          Vị trí kệ mặc định
          <input type="text" name="default_shelf" value="Kệ N1-01" placeholder="Ví dụ: Kệ V2-01" required>
        </label>
      </div>

      <div style="margin-top: 1rem;">
        <label style="font-weight: 600; display: block; margin-bottom: 0.5rem;">
          Cách 1: Tải lên tệp CSV
        </label>
        <input type="file" name="csv_file" accept=".csv,text/csv">
        <small style="color: var(--muted); display: block; margin-top: 4px;">Cột gợi ý: Tên sách, Tác giả, ISBN, NXB, Năm, Thể loại, Số bản sao, Kệ</small>
      </div>

      <div style="margin-top: 1.5rem;">
        <label style="font-weight: 600; display: block; margin-bottom: 0.5rem;">
          Cách 2: Hoặc dán trực tiếp danh sách sách (mỗi dòng một cuốn)
        </label>
        <textarea name="raw_data" rows="8" placeholder="Tên sách, Tác giả, ISBN, Nhà xuất bản, Năm xuất bản&#10;Lập trình Python thực chiến, Nguyễn Văn B, 978-604-1234-56-7, NXB Trẻ, 2022&#10;Văn học cổ điển phương Đông, Trần C, 978-604-9876-54-3, NXB Văn học, 2021" style="font-family: monospace; font-size: 0.88rem;"></textarea>
      </div>

      <div style="margin-top: 1.5rem;">
        <button class="button button-primary" type="submit">Kiểm tra và Xem trước dữ liệu (Preview) →</button>
      </div>
    </form>
  </section>
<?php else: ?>
  <!-- Preview Step -->
  <section class="panel">
    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
      <div>
        <h2 style="margin: 0;">Kết quả phân tích xem trước (<?= count($previewItems) ?> dòng)</h2>
        <small style="color: var(--muted);">Vui lòng kiểm tra lại trước khi xác nhận lưu vào hệ thống cơ sở dữ liệu.</small>
      </div>
      <div>
        <a class="button button-quiet button-small" href="<?= e(url('/admin/books/import')) ?>">Hủy & Nhập lại</a>
      </div>
    </div>

    <div class="table-scroll">
      <table class="data-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Mã dự kiến</th>
            <th>Tựa sách & Tác giả</th>
            <th>ISBN</th>
            <th>NXB & Năm</th>
            <th>Bản sao & Kệ</th>
            <th>Trạng thái kiểm tra</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($previewItems as $item): ?>
            <tr style="<?= $item['status'] === 'DUPLICATE_ISBN' ? 'background: #fff5f5;' : '' ?>">
              <td><?= (int)$item['index'] ?></td>
              <td><strong><?= e($item['book_code']) ?></strong></td>
              <td>
                <div style="font-weight: 600; color: var(--forest);"><?= e($item['title']) ?></div>
                <small style="color: var(--muted);"><?= e($item['author']) ?></small>
              </td>
              <td>
                <span style="font-family: monospace; font-size: 0.82rem;"><?= e($item['isbn'] ?: '—') ?></span>
              </td>
              <td><?= e($item['publisher']) ?> (<?= (int)$item['publication_year'] ?>)</td>
              <td><?= (int)$item['copies_count'] ?> bản · ⌖ <?= e($item['shelf_location']) ?></td>
              <td>
                <?php if ($item['status'] === 'VALID'): ?>
                  <span class="status-badge badge-success">✓ Sẵn sàng</span>
                <?php else: ?>
                  <span class="status-badge badge-warning">▲ <?= e($item['note']) ?></span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <form method="post" action="<?= e(url('/admin/books/import/commit')) ?>" style="margin-top: 24px; display: flex; justify-content: flex-end; gap: 12px;">
      <?= csrf_field() ?>
      <input type="hidden" name="confirmed_data" value="<?= e(json_encode($previewItems)) ?>">
      <a class="button button-quiet" href="<?= e(url('/admin/books/import')) ?>">Hủy bỏ</a>
      <button class="button button-primary" type="submit">Xác nhận nhập dữ liệu vào Thư viện (Commit Transaction) ✓</button>
    </form>
  </section>
<?php endif; ?>
