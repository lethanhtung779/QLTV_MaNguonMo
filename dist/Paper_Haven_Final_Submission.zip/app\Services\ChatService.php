<?php
declare(strict_types=1);
namespace Library\Services;
use PDO;
use Library\Repositories\ChatRepository;
use Library\Repositories\BookRepository;
use Library\Repositories\ReaderRepository;
use Library\Repositories\SystemSettingRepository;
use Library\Repositories\FineRepository;
use Library\Repositories\FavoriteRepository;

final class ChatService
{
 private ChatAuthorizationService $auth;
 private LibrarySearchService $search;
 private ChatResponseFormatter $format;
 public function __construct(private readonly PDO $db,private readonly ?LLMProvider $llm=null){$this->auth=new ChatAuthorizationService($db);$this->search=new LibrarySearchService($db);$this->format=new ChatResponseFormatter();}
 public function reset():void{unset($_SESSION['_chat']);}
 private function context(?array $user):void {
  $identity=$this->auth->identity($user);$old=$_SESSION['_chat']??[];
  if(($old['identity']??null)!==$identity||time()-(int)($old['time']??0)>1200)$_SESSION['_chat']=['identity'=>$identity,'books'=>[],'selected'=>null];
  $_SESSION['_chat']['time']=time();
 }
 public function state():array{$u=$this->auth->user();$this->context($u);return ['greeting'=>'Chào bạn! Tôi giúp tìm sách, kiểm tra sách còn và hướng dẫn quy định thư viện.','suggestions'=>['Tìm sách khoa học','Gợi ý sách lập trình web','Tôi đang mượn sách nào?','Quy định mượn sách'],'ai_available'=>($this->llm??new LLMProvider())->enabled(),'history_stored'=>false,'csrf'=>\Library\Core\Csrf::token()];}
 public function reply(string $message,bool $useAi=false):array {
  $user=$this->auth->user();$this->context($user);$plan=(new IntentClassifier())->classify($message);$intent=$plan['intent'];$s=$plan['normalized'];$publicOnly=!$this->auth->allows($user,'books.view');$repo=new ChatRepository($this->db);
  if($intent==='blocked')return $this->format->response($intent,'Tôi chỉ hỗ trợ tra cứu thư viện theo quyền của bạn; không cung cấp mật khẩu, thông tin người khác hoặc thực thi SQL.');
  if($intent==='help') {
   $text="Tôi có thể giúp bạn:\n• Tìm sách theo tên, tác giả, ISBN hoặc thể loại; xem bìa, tình trạng còn sách và mở chi tiết.\n• Gợi ý sách theo chủ đề từ danh mục thư viện.\n• Hướng dẫn đăng ký, đặt trước, mượn/trả và quy định hiện hành.\n• Khi đăng nhập Độc giả: xem sách đang mượn, hạn trả, lịch sử, tủ sách yêu thích và phí còn nợ của bạn.\nBạn có thể hỏi tiếp về cuốn sách vừa tìm, chẳng hạn: ‘Cuốn thứ hai còn không?’";
   if($this->auth->allows($user,'loans.view')&&$this->auth->allows($user,'reports.view'))$text.="\n• Theo quyền nhân viên: tra cứu báo cáo sách quá hạn, hướng dẫn kiểm kê kho và in tem nhãn.";
   if(($user['role']??'')==='admin'&&$this->auth->allows($user,'reports.view'))$text.="\n• Theo quyền Admin: xem thống kê mượn, độc giả và phí chưa thu.";
   $text.="\nTôi tra cứu dữ liệu thật của thư viện; gia hạn, đặt trước và thanh toán được hướng dẫn tới trang nghiệp vụ để bạn thực hiện.";
   return $this->format->response($intent,$text,[],[['label'=>'Mở danh mục sách','url'=>url('/catalog')]],['Tìm sách tâm lý','Tôi muốn học lập trình web','Tôi đang mượn sách nào?','Quy định mượn sách']);
  }
  if($intent==='unknown'&&$useAi){$provider=$this->llm??new LLMProvider();$extra=$provider->classify($message);if($extra){$plan=$extra;$intent=$extra['intent'];}}
  if(in_array($intent,['search','recommend'],true)) {
   $books=$this->search->search($plan['query'],$plan['limit'],$publicOnly);$_SESSION['_chat']['books']=array_column($books,'id');$_SESSION['_chat']['selected']=count($books)===1?(int)$books[0]['id']:null;
   $text=$books?($intent==='recommend'?'Gợi ý dựa trên từ khóa, thể loại/mô tả và ưu tiên bản khả dụng; chưa phải cá nhân hóa học từ hành vi.':'Các sách phù hợp trong dữ liệu thư viện:'):'Chưa tìm thấy sách phù hợp trong thư viện. Bạn thử tên sách, tác giả, ISBN hoặc từ khóa ngắn hơn nhé.';
   if($intent==='recommend'&&str_contains($s,'nguoi moi'))$text='Chưa có dữ liệu độ khó để khẳng định sách phù hợp người mới. '.$text;
   return $this->format->response($intent,$text,$books,[],['Cuốn thứ hai còn không?','Quy định đặt trước','Tìm sách tin học']);
  }
  if($intent==='context') {
   $ids=$_SESSION['_chat']['books']??[];$selected=$_SESSION['_chat']['selected']??null;
   if(preg_match('/cuon (?:thu )?(mot|hai|ba|bon|nam|sau|bay|tam|chin|muoi|[1-9][0-9]?)/',$s,$m)){$words=['mot'=>1,'hai'=>2,'ba'=>3,'bon'=>4,'nam'=>5,'sau'=>6,'bay'=>7,'tam'=>8,'chin'=>9,'muoi'=>10];$index=($words[$m[1]]??(int)$m[1])-1;$selected=$ids[$index]??null;}
   if(!$selected&&count($ids)===1)$selected=$ids[0];$book=$selected?$this->search->find((int)$selected,$publicOnly):null;
   if(!$book)return $this->format->response($intent,'Tôi chưa xác định được cuốn sách. Hãy tìm lại hoặc nói rõ thứ tự trong danh sách vừa trả lời.');
   $_SESSION['_chat']['selected']=(int)$book['id'];return $this->format->response($intent,$book['title'].': '.((int)$book['available_copies']>0?'còn '.$book['available_copies'].' bản có thể mượn.':'hiện chưa có bản khả dụng.').' Tình trạng được kiểm tra lại từ MySQL.',$book?[$book]:[]);
  }
  if($intent==='personal_favorites') {
   $readerId=$this->auth->readerId($user);
   if(!$readerId)return $this->format->response($intent,'Hãy đăng nhập tài khoản độc giả để xem tủ sách và danh sách yêu thích của bạn.',[],[['label'=>'Đăng nhập độc giả','url'=>url('/login')]]);
   $favRepo=new FavoriteRepository($this->db);$favs=$favRepo->listForReader($readerId);$link=[['label'=>'Mở tủ sách của tôi','url'=>url('/account/bookshelf')]];
   if(!$favs)return $this->format->response($intent,'Tủ sách của bạn hiện chưa có sách yêu thích nào. Hãy khám phá danh mục và bấm nút "♥ Lưu vào yêu thích" ở cuốn sách bạn quan tâm.',[],$link);
   $text='Tủ sách của bạn có '.count($favs).' cuốn sách đã lưu yêu thích:';
   foreach(array_slice($favs,0,5) as $f)$text.="\n• ".$f['title'].(!empty($f['author'])?' — '.$f['author']:'');
   return $this->format->response($intent,$text,[],$link);
  }
  if($intent==='print_labels_guide') {
   return $this->format->response($intent,'Để in tem nhãn mã vạch Code 128 và mã QR cho sách: Hãy vào mục Quản lý sách > Bản sao > bấm nút "In tem nhãn gáy sách". Hệ thống hỗ trợ xem trước và in nhanh trên khổ giấy nhiệt hoặc A4 độ nét cao.',[],[['label'=>'Quản lý sách','url'=>url('/admin/books')]]);
  }
  if($intent==='inventory_guide') {
   return $this->format->response($intent,'Để kiểm kê kho thư viện: Hãy vào mục "Kiểm kê kho" (/admin/inventory/audits), bấm "Tạo đợt kiểm kê mới". Bạn có thể quét mã bản sao bằng máy đọc USB hoặc camera để đối soát tự động vị trí thực tế so với vị trí kệ trên hệ thống.',[],[['label'=>'Kiểm kê kho','url'=>url('/admin/inventory/audits')]]);
  }
  if(in_array($intent,['personal_loans','personal_history','personal_fines','renewal'],true)) {
   $readerId=$this->auth->readerId($user);if(!$readerId)return $this->format->response($intent,'Hãy đăng nhập tài khoản độc giả của bạn để tra cứu thông tin cá nhân.',[],[['label'=>'Đăng nhập độc giả','url'=>url('/login')]]);
   $link=[['label'=>'Mở tài khoản và nghiệp vụ','url'=>url('/account')]];
   if($intent==='personal_fines')return $this->format->response($intent,'Tổng phí còn nợ của bạn tính đến hôm nay: '.number_format((new FineService($this->db))->previewBalance($readerId),2,',','.').' ₫. Mức phí dùng chính sách đã lưu trên phiếu; chatbot không thu tiền.',[],$link);
   if($intent==='renewal'){$policy=(new SystemSettingRepository($this->db))->currentPolicy();return $this->format->response($intent,'Gia hạn tối đa '.$policy['max_renewals'].' lần, mỗi lần '.$policy['renewal_days'].' ngày theo chính sách hiện hành. Bản sách phải đang mượn, chưa quá hạn, còn lượt gia hạn, không có người đặt trước và thẻ còn hiệu lực. Mở tài khoản để chọn bản sách; backend sẽ kiểm tra lại và yêu cầu bạn thực hiện thao tác. Chatbot chưa gia hạn sách.',[],$link);}
   $items=$repo->loans($readerId,$intent==='personal_history');if(str_contains($s,'qua han'))$items=array_values(array_filter($items,fn($i)=>$i['returned_at']===null&&$i['due_date']<date('Y-m-d')));
   $text=$items?'Thông tin của bạn (tối đa 20 bản gần nhất):':'Không có bản sách phù hợp với yêu cầu trong hồ sơ của bạn.';
   foreach($items as $item)$text.="\n• ".$item['title'].' — '.$item['copy_code'].' — hạn '.date('d/m/Y',strtotime($item['due_date'])).($item['returned_at']!==null?' — đã trả':($item['due_date']<date('Y-m-d')?' — quá hạn':' — đang mượn'));
   return $this->format->response($intent,$text,[],$link);
  }
  if($intent==='policy') {
   $p=(new SystemSettingRepository($this->db))->currentPolicy();$message='Chính sách hiện hành #'.$p['id'].': tối đa '.$p['max_books_per_reader'].' bản/độc giả, mượn '.$p['default_loan_days'].' ngày; gia hạn '.$p['max_renewals'].' lần, mỗi lần '.$p['renewal_days'].' ngày; phí quá hạn '.number_format((float)$p['fine_per_overdue_day'],2,',','.').' ₫/ngày. Phiếu cũ giữ chính sách phí đã chốt.';
   $message.="\nĐăng ký qua mục Đăng ký thẻ; tìm sách trong Danh mục. Đăng nhập độc giả và mở chi tiết sách để đặt trước khi chưa có bản khả dụng. Mượn/trả và thanh toán thực hiện với thủ thư. Thẻ bị khóa/hết hạn cần liên hệ thủ thư để kiểm tra, không tự mở lại bằng chat.";
   return $this->format->response($intent,$message,[],[['label'=>'Đăng ký thẻ','url'=>url('/register')],['label'=>'Danh mục sách','url'=>url('/catalog')],['label'=>'Liên hệ thư viện','url'=>url('/').'#contact']]);
  }
  if($intent==='staff_report') {
   if(!$this->auth->allows($user,'loans.view')||!$this->auth->allows($user,'reports.view'))return $this->format->response('forbidden','Bạn không có quyền xem báo cáo nghiệp vụ nội bộ.');
   if(str_contains($s,'het ban')){if(!$this->auth->allows($user,'books.view'))return $this->format->response('forbidden','Bạn không có quyền xem kho sách nội bộ.');return $this->format->response($intent,'Các sách chưa có bản khả dụng (tối đa 10):',$repo->staff('unavailable'));}
   $text='Có '.$repo->overdueCount().' bản đang mượn quá hạn.';foreach($repo->staff('overdue') as $r)$text.="\n• ".$r['loan_code'].' — '.$r['overdue_copies'].' bản quá hạn — hạn sớm nhất '.date('d/m/Y',strtotime($r['earliest_due']));return $this->format->response($intent,$text,[],[['label'=>'Xử lý phiếu mượn','url'=>url('/admin/loans?status=overdue')]]);
  }
  if($intent==='admin_report') {
   if(($user['role']??'')!=='admin'||!$this->auth->allows($user,'reports.view'))return $this->format->response('forbidden','Báo cáo này dành cho Admin có quyền xem báo cáo.');
   $data=$repo->admin();$text='Tháng '.date('m/Y').': '.$data['loans'].' phiếu mượn; '.$data['readers'].' độc giả đang hoạt động.';
   if(str_contains($s,'phat')){$sum=(new FineService($this->db))->previewTotalBalance();$text.="\nTổng phí chưa thu tính đến hôm nay: ".number_format($sum,2,',','.').' ₫.';}
   $text.="\nTop tối đa 5 đầu sách theo số bản mượn trong tháng:";foreach($data['top'] as $row)$text.="\n• ".$row['title'].' — '.$row['borrow_count'].' lượt bản sách';if(!$data['top'])$text.=' chưa có dữ liệu mượn trong tháng.';
   return $this->format->response($intent,$text,[],[['label'=>'Báo cáo thư viện','url'=>url('/admin/statistics')]]);
  }
  return $this->format->response($intent,$intent==='greeting'?'Chào bạn! Tôi có thể tìm sách, kiểm tra bản còn, tra cứu hồ sơ của bạn và hướng dẫn quy định.':'Tôi chưa hiểu rõ yêu cầu. Bạn có thể hỏi tên sách, thể loại, quy định hoặc thông tin mượn của mình. Tôi không trả lời kiến thức ngoài dữ liệu thư viện.');
 }
}
