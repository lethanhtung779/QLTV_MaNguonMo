<div class="panel-header">
  <div>
    <a class="back-link" href="<?= e(url('/admin/inventory/audits')) ?>">← Quay lại danh sách đợt kiểm kê</a>
    <span class="eyebrow">ĐỢT KIỂM KÊ: <?= e($audit['audit_code']) ?></span>
    <h1><?= e($audit['title']) ?></h1>
    <p>Người tạo: <strong><?= e($audit['starter_name']) ?></strong> · Bắt đầu: <?= e(date('d/m/Y H:i', strtotime($audit['started_at']))) ?> <?= $audit['completed_at'] ? '· Hoàn thành: ' . e(date('d/m/Y H:i', strtotime($audit['completed_at']))) : '' ?></p>
  </div>
  <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
    <a class="button button-outline" href="<?= e(url('/admin/inventory/audits/' . (int) $audit['id'] . '/export')) ?>">Xuất biên bản CSV ↗</a>
    <?php if ($audit['status'] !== 'completed'): ?>
      <form action="<?= e(url('/admin/inventory/audits/' . (int) $audit['id'] . '/complete')) ?>" method="post" data-confirm="Bạn có chắc chắn muốn hoàn tất và chốt đợt kiểm kê này? Thao tác này sẽ khóa đợt kiểm kê.">
        <?= csrf_field() ?>
        <button class="button button-primary" type="submit">Hoàn tất & Chốt kiểm kê ✓</button>
      </form>
    <?php endif; ?>
  </div>
</div>

<!-- KPI Cards -->
<div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
  <div class="stat-card" style="background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <span class="stat-label">Tổng sách dự kiến</span>
    <span class="stat-value" style="font-size: 2rem; font-weight: 700; color: #193E30;"><?= (int) $audit['total_expected'] ?></span>
  </div>
  <div class="stat-card" style="background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <span class="stat-label">Đã quét thực tế</span>
    <span class="stat-value" style="font-size: 2rem; font-weight: 700; color: #28a745;"><?= (int) $audit['total_scanned'] ?></span>
  </div>
  <div class="stat-card" style="background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <span class="stat-label">Khớp vị trí kệ</span>
    <span class="stat-value" style="font-size: 2rem; font-weight: 700; color: #193E30;"><?= (int) $audit['total_matched'] ?></span>
  </div>
  <div class="stat-card" style="background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <span class="stat-label">Sai lệch vị trí</span>
    <span class="stat-value" style="font-size: 2rem; font-weight: 700; color: #ffc107;"><?= (int) $audit['total_misplaced'] ?></span>
  </div>
  <div class="stat-card" style="background: #fff; padding: 1.25rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <span class="stat-label">Thiếu / Chưa thấy</span>
    <span class="stat-value" style="font-size: 2rem; font-weight: 700; color: #dc3545;"><?= (int) $audit['total_missing'] ?></span>
  </div>
</div>

<?php if ($audit['status'] !== 'completed'): ?>
  <!-- Scan Barcode Form -->
  <section class="admin-section" style="background: #fff; padding: 1.5rem; border-radius: 8px; border: 2px solid #193E30; margin-bottom: 2rem;">
    <div class="section-heading" style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 0.75rem;">
      <div>
        <span class="eyebrow">QUÉT MÃ / NHẬP LIỆU</span>
        <h2>Quét mã bản sao sách (Máy quét USB, gõ tay hoặc Camera)</h2>
      </div>
      <button type="button" class="button button-outline" id="btn-toggle-camera" style="border-color: #193E30; color: #193E30;">
        📷 Bật Camera quét mã
      </button>
    </div>

    <!-- Live Camera Scanner Box -->
    <div id="camera-scanner-panel" style="display: none; background: #F8F3EB; padding: 1rem; border-radius: 8px; border: 1px dashed #193E30; margin-bottom: 1.25rem; text-align: center;">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
        <strong style="color: #193E30;">Khung ngắm quét mã vạch / QR qua Camera</strong>
        <button type="button" class="button button-small button-quiet" id="btn-close-camera">Đóng camera ✕</button>
      </div>
      <div style="position: relative; max-width: 420px; margin: 0 auto; overflow: hidden; border-radius: 6px; background: #000;">
        <video id="camera-stream" playsinline autoplay muted style="width: 100%; height: auto; display: block;"></video>
        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 75%; height: 55%; border: 2px dashed #C58B54; pointer-events: none;"></div>
      </div>
      <p id="camera-feedback" style="margin-top: 0.5rem; color: #74685c; font-size: 0.875rem;">Đang kết nối camera thiết bị...</p>
    </div>

    <form action="<?= e(url('/admin/inventory/audits/' . (int) $audit['id'] . '/scan')) ?>" method="post" style="display: grid; grid-template-columns: 2fr 1fr 1fr auto; gap: 1rem; align-items: end;">
      <?= csrf_field() ?>
      <label>
        Mã bản sao hoặc Barcode (Quét máy đọc USB tại đây)
        <input type="text" name="code" required autofocus placeholder="VD: B001-C01 hoặc mã vạch" style="font-size: 1.1rem; padding: 0.6rem;">
      </label>
      <label>
        Tình trạng thực tế
        <select name="condition" style="padding: 0.6rem;">
          <option value="good">Tốt / Bình thường</option>
          <option value="worn">Hao mòn nhẹ</option>
          <option value="damaged">Hư hỏng</option>
          <option value="lost">Mất / Không tìm thấy</option>
        </select>
      </label>
      <label>
        Kệ đang kiểm kê
        <input type="text" name="location" placeholder="VD: Kệ A-01" style="padding: 0.6rem;">
      </label>
      <button class="button button-primary" type="submit" style="padding: 0.65rem 1.5rem; height: fit-content;">Ghi nhận (Enter) <span>✓</span></button>
    </form>
    <small style="color: #74685c; margin-top: 0.5rem; display: block;">Mẹo: Đặt con trỏ chuột vào ô mã bản sao và dùng máy quét mã vạch USB bấm còi, hoặc bấm "Bật Camera quét mã" để nhận diện tự động.</small>
  </section>
<?php endif; ?>

<!-- Scan Results and Missing Copies -->
<div style="display: grid; grid-template-columns: 1fr; gap: 2rem;">
  <!-- Scanned items -->
  <section class="admin-section" style="background: #fff; padding: 1.5rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <div class="section-heading">
      <div>
        <span class="eyebrow">DANH SÁCH BẢN SAO ĐÃ QUÉT</span>
        <h3>Bản sao đã ghi nhận thực tế (<?= count($items) ?>)</h3>
      </div>
    </div>
    <?php if ($items): ?>
      <div class="table-wrap">
        <table class="data-table" style="width: 100%;">
          <thead>
            <tr>
              <th>Mã bản sao</th>
              <th>Tên sách</th>
              <th>Vị trí hệ thống</th>
              <th>Vị trí quét</th>
              <th>Tình trạng quét</th>
              <th>Khớp vị trí</th>
              <th>Thời gian quét</th>
              <th>Người quét</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr>
                <td><strong><?= e($item['copy_code']) ?></strong></td>
                <td><?= e($item['book_title']) ?></td>
                <td><?= e($item['expected_location'] ?: 'Chưa gán') ?></td>
                <td><strong><?= e($item['scanned_location'] ?: 'Không xác định') ?></strong></td>
                <td><?= e(['good'=>'Tốt','worn'=>'Hao mòn','damaged'=>'Hỏng','lost'=>'Mất'][$item['scanned_condition']] ?? $item['scanned_condition']) ?></td>
                <td>
                  <span class="status-badge <?= $item['is_matched'] ? 'badge-success' : 'badge-warning' ?>">
                    <?= $item['is_matched'] ? 'Đúng kệ' : 'Lệch vị trí' ?>
                  </span>
                </td>
                <td><?= e(date('d/m/Y H:i:s', strtotime($item['scanned_at']))) ?></td>
                <td><?= e($item['scanner_name']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="color: #74685c; margin: 0;">Chưa có bản sao nào được quét trong đợt kiểm kê này.</p>
    <?php endif; ?>
  </section>

  <!-- Missing copies -->
  <section class="admin-section" style="background: #fff; padding: 1.5rem; border-radius: 8px; border: 1px solid #E8D8C5;">
    <div class="section-heading">
      <div>
        <span class="eyebrow">DANH SÁCH CHƯA QUÉT ĐỐI SOÁT</span>
        <h3>Bản sao thiếu hoặc chưa tìm thấy (<?= count($missing) ?>)</h3>
      </div>
    </div>
    <?php if ($missing): ?>
      <div class="table-wrap">
        <table class="data-table" style="width: 100%;">
          <thead>
            <tr>
              <th>Mã bản sao</th>
              <th>Tên sách</th>
              <th>Vị trí kệ dự kiến</th>
              <th>Tình trạng hệ thống</th>
              <th>Trạng thái</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($missing as $m): ?>
              <tr>
                <td><strong style="color: #dc3545;"><?= e($m['copy_code']) ?></strong></td>
                <td><?= e($m['book_title']) ?></td>
                <td><?= e($m['shelf_location'] ?: 'Chưa gán') ?></td>
                <td><?= e(['good'=>'Tốt','worn'=>'Hao mòn','damaged'=>'Hỏng','lost'=>'Mất'][$m['item_condition']] ?? $m['item_condition']) ?></td>
                <td>
                  <span class="status-badge <?= $m['status'] === 'available' ? 'badge-muted' : ($m['status'] === 'on_loan' ? 'badge-warning' : 'badge-danger') ?>">
                    <?= e(['available'=>'Chưa quét','on_loan'=>'Đang mượn','reserved'=>'Đã giữ chỗ','damaged'=>'Hỏng','lost'=>'Mất'][$m['status']] ?? $m['status']) ?>
                  </span>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div style="padding: 1.5rem; text-align: center; background: #e8f5e9; border-radius: 6px; color: #2e7d32;">
        <strong>Tuyệt vời! Toàn bộ bản sao dự kiến đã được quét đối soát đầy đủ.</strong>
      </div>
    <?php endif; ?>
  </section>
</div>

<script src="<?= e(asset('js/inventory-scanner.js')) ?>" defer></script>
