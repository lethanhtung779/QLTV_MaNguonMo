<?php
$coverTitle = (string) ($book['title'] ?? $book['book_title'] ?? '');
$coverAuthor = (string) ($book['author'] ?? '');
$coverSource = book_cover($book, $size);
?>
<?php if ($coverSource): ?><img class="book-cover" src="<?= e($coverSource) ?>" alt="Bìa sách <?= e($coverTitle) ?> — <?= e($coverAuthor) ?>" loading="lazy" decoding="async" data-cover-fallback="<?= e(cover_fallback($book)) ?>"><?php endif; ?>
<span class="book-cover book-cover-fallback <?= e(cover_fallback($book)) ?>" data-book-cover-placeholder<?= $coverSource ? ' hidden' : '' ?>><span class="cover-fallback-title"><?= e($coverTitle) ?></span><small class="cover-fallback-author"><?= e($coverAuthor) ?></small><small class="cover-fallback-note">Chưa có bìa xác minh</small></span>
