<?php
declare(strict_types=1);

namespace Library\Controllers;

use Library\Core\Database;
use Library\Core\Session;

final class BookImportController extends Controller
{
    public function index(): void
    {
        require_permission('books.create');
        $db = Database::connection();
        $categories = $db->query('SELECT id, name FROM categories ORDER BY id')->fetchAll(\PDO::FETCH_ASSOC);

        $this->render('admin/book_import', [
            'title' => 'Nhập sách hàng loạt an toàn',
            'categories' => $categories,
            'previewItems' => null,
            'errors' => [],
        ]);
    }

    public function preview(): void
    {
        require_permission('books.create');
        validate_csrf();
        $db = Database::connection();
        $categories = $db->query('SELECT id, name FROM categories ORDER BY id')->fetchAll(\PDO::FETCH_ASSOC);
        $catMap = [];
        foreach ($categories as $c) {
            $catMap[mb_strtolower(trim($c['name']))] = (int) $c['id'];
            $catMap[(string) $c['id']] = (int) $c['id'];
        }

        $importType = (string) ($_POST['import_type'] ?? 'csv');
        $rawText = trim((string) ($_POST['raw_data'] ?? ''));
        $defaultCategoryId = (int) ($_POST['default_category_id'] ?? 1);
        $defaultCopies = max(1, min(10, (int) ($_POST['default_copies'] ?? 2)));
        $defaultShelf = trim((string) ($_POST['default_shelf'] ?? 'Kệ N1-01'));

        $rows = [];
        $errors = [];

        // Handle uploaded file if present
        if (!empty($_FILES['csv_file']['tmp_name']) && is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
            $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
            if ($handle) {
                $header = fgetcsv($handle);
                while (($data = fgetcsv($handle)) !== false) {
                    if (count($data) >= 2) {
                        $rows[] = $data;
                    }
                }
                fclose($handle);
            }
        } elseif ($rawText !== '') {
            $lines = explode("\n", $rawText);
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) continue;
                // Support comma, tab, or pipe delimiter
                $delimiter = str_contains($line, "\t") ? "\t" : (str_contains($line, '|') ? '|' : ',');
                $parts = array_map('trim', str_getcsv($line, $delimiter));
                if (count($parts) >= 2) {
                    $rows[] = $parts;
                }
            }
        }

        if (empty($rows)) {
            $errors[] = 'Không có dữ liệu hợp lệ được tìm thấy để nhập. Vui lòng kiểm tra lại tệp CSV hoặc nội dung dán.';
        }

        // Validate and sanitize each row
        $previewItems = [];
        $existingIsbns = $db->query("SELECT isbn FROM books WHERE isbn IS NOT NULL AND isbn != ''")->fetchAll(\PDO::FETCH_COLUMN);
        $existingCodes = $db->query('SELECT book_code FROM books')->fetchAll(\PDO::FETCH_COLUMN);

        $isbnSet = array_flip($existingIsbns);
        $codeSet = array_flip($existingCodes);

        $nextCodeIndex = 900;

        foreach ($rows as $idx => $r) {
            // Anti-formula injection: neutralize leading =, +, -, @
            $cleanRow = array_map(function($val) {
                $v = trim((string) $val);
                if ($v !== '' && in_array($v[0], ['=', '+', '-', '@'], true)) {
                    $v = "'" . $v;
                }
                return $v;
            }, $r);

            $title = $cleanRow[0] ?? '';
            $author = $cleanRow[1] ?? '';
            $isbn = $cleanRow[2] ?? '';
            $publisher = $cleanRow[3] ?? 'NXB Tổng hợp';
            $year = !empty($cleanRow[4]) ? (int) $cleanRow[4] : (int) date('Y');
            $categoryName = $cleanRow[5] ?? '';
            $copiesCount = !empty($cleanRow[6]) ? max(1, min(10, (int)$cleanRow[6])) : $defaultCopies;
            $shelf = !empty($cleanRow[7]) ? $cleanRow[7] : $defaultShelf;

            if ($title === '' || $author === '') {
                continue;
            }

            // Determine category
            $catId = $defaultCategoryId;
            if ($categoryName !== '' && isset($catMap[mb_strtolower($categoryName)])) {
                $catId = $catMap[mb_strtolower($categoryName)];
            }

            // Generate book code
            do {
                $code = sprintf('B%03d', $nextCodeIndex++);
            } while (isset($codeSet[$code]));
            $codeSet[$code] = true;

            $status = 'VALID';
            $note = 'Hợp lệ';

            if ($isbn !== '' && isset($isbnSet[$isbn])) {
                $status = 'DUPLICATE_ISBN';
                $note = 'Mã ISBN đã tồn tại trong thư viện';
            }

            $previewItems[] = [
                'index' => $idx + 1,
                'book_code' => $code,
                'title' => $title,
                'author' => $author,
                'isbn' => $isbn,
                'publisher' => $publisher,
                'publication_year' => $year,
                'category_id' => $catId,
                'copies_count' => $copiesCount,
                'shelf_location' => $shelf,
                'status' => $status,
                'note' => $note,
            ];
        }

        $this->render('admin/book_import', [
            'title' => 'Xem trước dữ liệu nhập hàng loạt',
            'categories' => $categories,
            'previewItems' => $previewItems,
            'errors' => $errors,
        ]);
    }

    public function commit(): void
    {
        require_permission('books.create');
        validate_csrf();
        $db = Database::connection();

        $jsonData = (string) ($_POST['confirmed_data'] ?? '');
        $items = json_decode($jsonData, true);

        if (!is_array($items) || empty($items)) {
            Session::flash('error', 'Không có dữ liệu hợp lệ để lưu.');
            redirect('/admin/books/import');
            return;
        }

        $db->beginTransaction();
        try {
            $insertBook = $db->prepare('
                INSERT INTO books (
                    book_code, title, author, isbn, category_id, publisher, publication_year,
                    description, total_copies, cover_url, is_active, is_public, created_at, updated_at
                ) VALUES (
                    :book_code, :title, :author, :isbn, :category_id, :publisher, :publication_year,
                    :description, :total_copies, NULL, 1, 1, NOW(), NOW()
                )
            ');

            $insertCopy = $db->prepare('
                INSERT INTO book_copies (
                    book_id, copy_code, barcode, shelf_location, item_condition, status, created_at, updated_at
                ) VALUES (
                    :book_id, :copy_code, :barcode, :shelf_location, "good", "available", NOW(), NOW()
                )
            ');

            $imported = 0;
            $copiesCountTotal = 0;

            foreach ($items as $item) {
                if (($item['status'] ?? '') === 'DUPLICATE_ISBN') {
                    continue; // Skip duplicates safely
                }

                $insertBook->execute([
                    ':book_code' => $item['book_code'],
                    ':title' => $item['title'],
                    ':author' => $item['author'],
                    ':isbn' => $item['isbn'] ?: null,
                    ':category_id' => (int) $item['category_id'],
                    ':publisher' => $item['publisher'],
                    ':publication_year' => (int) $item['publication_year'],
                    ':description' => "Ấn bản tài liệu lưu hành nội bộ thư viện Paper Haven. Tác phẩm: {$item['title']} - Tác giả: {$item['author']}.",
                    ':total_copies' => (int) $item['copies_count'],
                ]);
                $bookId = (int) $db->lastInsertId();
                $imported++;

                $copiesCount = (int) $item['copies_count'];
                $shelf = $item['shelf_location'];
                for ($i = 1; $i <= $copiesCount; $i++) {
                    $copyCode = sprintf('%s-%04d', $item['book_code'], $i);
                    $insertCopy->execute([
                        ':book_id' => $bookId,
                        ':copy_code' => $copyCode,
                        ':barcode' => $copyCode,
                        ':shelf_location' => $shelf,
                    ]);
                    $copiesCountTotal++;
                }
            }

            $db->commit();
            Session::flash('success', "Đã nhập thành công {$imported} đầu sách mới và khởi tạo {$copiesCountTotal} bản sao vật lý kèm vị trí kệ!");
            redirect('/admin/metadata-quality');
        } catch (\Throwable $e) {
            $db->rollBack();
            Session::flash('error', 'Lỗi nhập dữ liệu: ' . $e->getMessage());
            redirect('/admin/books/import');
        }
    }
}
