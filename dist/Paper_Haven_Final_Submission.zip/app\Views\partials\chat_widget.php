<link rel="stylesheet" href="<?= e(asset('css/chat.css')) ?>">
<div class="library-chat" data-library-chat data-endpoint="<?= e(url('/chat')) ?>" data-csrf="<?= e(\Library\Core\Csrf::token()) ?>">
  <button class="chat-launch" type="button" aria-label="Mở Trợ lý Paper Haven" aria-expanded="false" aria-controls="library-chat-panel">▤ <span>Trợ lý Paper Haven</span></button>
  <section class="chat-panel" id="library-chat-panel" aria-label="Trợ lý Paper Haven" hidden>
    <header class="chat-header"><div><h2>Trợ lý Paper Haven</h2><small>Tra cứu từ kho sách Paper Haven</small></div><button type="button" data-chat-minimize aria-label="Thu nhỏ trò chuyện">−</button><button type="button" data-chat-close aria-label="Đóng trò chuyện">×</button></header>
    <div class="chat-messages" role="log" aria-live="polite" aria-relevant="additions" tabindex="0"></div>
    <div class="chat-status" role="status" aria-live="polite"></div>
    <div class="chat-suggestions" aria-label="Câu hỏi gợi ý"></div>
    <form class="chat-form"><label class="sr-only" for="library-chat-input">Câu hỏi cho Trợ lý Paper Haven</label><textarea id="library-chat-input" rows="2" maxlength="1000" placeholder="Bạn muốn tìm sách gì?" required></textarea><button type="submit" aria-label="Gửi câu hỏi">Gửi</button></form>
    <div class="chat-options"><button type="button" data-chat-reset>Cuộc trò chuyện mới</button><label data-chat-ai hidden><input type="checkbox" name="chat_ai">Cho phép gửi câu hỏi tìm sách khó tới AI</label></div>
  </section>
</div>
<script src="<?= e(asset('js/chat.js')) ?>" defer></script>
